<?php





$conn = new mysqli('localhost' , 'root' , '' , 'testsql');
$conn->set_charset('utf8');
$stmt = $conn->stmt_init();
$query = "select * from users where id > ? ";
$stmt->prepare($query);
$id = 1;
$stmt->bind_param('i', $id);
$stmt->bind_result($id, $title);
$stmt->execute();
while ($stmt->fetch()){
    echo $title . "<br>";
}
