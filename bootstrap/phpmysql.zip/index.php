<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHPMySQL</title>
</head>
<body>
<a href="form.php">form</a>
<a href="sql.php">sql</a>
</body>
</html>



















<?php
$a = 10;
$b = 5;
$c = null;
$d = "10";
$e = "yes";
$f = "no";
$g = $b;
$h = 10;
$i = [
    $a ,
    $b ,
    $c ,
    $d ,
    $e ,
    $f ,
    $g ,
    $h
];

//echo $z = ($a < $b) ? $e : $f;







//echo $c = $c ?? "12";




//switch ($a) {
//    case 12 :
//        echo $e;
//        break;
//    case 101 :
//    echo $e;
//    break;
//    default : echo $f;
//}



//while ($g <= $a ) {
//    echo "$g <br>";
//    $g++;
//}


//do {
//    echo "$e <br>";
//    $h--;
//} while ($h >= 0);





//for ($y = 1; $y <= 10 ; ++$y ) {
//    echo "?GH <br>";
//}




//foreach ($i as $x) {
//    echo $x . '<br>';
//}





