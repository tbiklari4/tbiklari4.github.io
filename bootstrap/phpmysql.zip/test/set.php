<?php
require 'config.php';
$name = $_POST['name'];
$sql = "INSERT INTO users (name) VALUES (?)";
$stmt = $con -> stmt_init();
$stmt -> prepare($sql);
$stmt -> bind_param('s',$name);
$stmt -> execute();
header("Location: http://127.0.0.1/phpmysql/test/index.php");