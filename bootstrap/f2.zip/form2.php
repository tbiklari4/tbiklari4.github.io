<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form method="post">
    <input type="text" name="name" placeholder="نام">
    <input type="email" name="email" placeholder="ایمیل">
    <input type="password" name="password" placeholder="رمز">
    <button type="submit">ارسال</button>
</form>
<?php
$con = new PDO ("mysql:host=localhost;dbname=testsql;charset=utf8","root","");
if (isset($_POST['name']) and isset($_POST['email']) and isset($_POST['password'])) {
    $sql = "INSERT INTO `USERS` (`name`,`email`,`password`) VALUES (:name,:email,:password) ";
    $sql = $con->prepare($sql);
    $stmt = [
        ":name" => $_POST['name'],
        ":email" => $_POST['email'],
        ":password" => $_POST['password']

    ];
    $sql->execute($stmt);
} else {
    echo "فیلد ها نباید خالی باشند";
}
$sql = "SELECT * FROM `users`";
$users = $con->query($sql);
foreach ($users as $user) {
    ?>

    <table>
        <tr>
            <th>ID</th>
            <th>نام</th>
            <th>ایمیل</th>
            <th>رمز</th>
        </tr>
        <tr>
            <td><?php echo $user['id'];?></td>
            <td><?php echo $user['name'];?></td>
            <td><?php echo $user['email'];?></td>
            <td><?php echo $user['password'];?></td>
        </tr>
    </table>


<?php
}
?>
</body>
</html>