<?php

$db = new PDO(DSN,DBU,DBP);