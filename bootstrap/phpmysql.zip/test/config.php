<?php
$hostN = "localhost";
$username = "root";
$password = "";
$dbN = "testsql";

$con = new mysqli($hostN,$username,$password,$dbN);
$con -> set_charset("utf8");