<?php
const DSN = "mysql:host=localhost;dbname=weblog;charset=utf8";
const DBU = "root";
const DBP = "";