<?php
include "config.php";
include "db.php";
$query = "SELECT * FROM `category`";
$category = $db -> query($query);
?>

<!DOCTYPE html>

<html><!--------ملت وب مرجع خرید و فروش و همچنین انواع قالب های وردپرس و html mellatweb.com------------->
<!-- Begin Head -->

<head>
    <title>Wlog - Blog and Magazine HTML template </title>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="Blog">
    <meta name="keywords" content="">
    <meta name="author" content="kamleshyadav">
    <meta name="MobileOptimized" content="320">
    <!--Start Style -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="js/plugins/swiper/swiper.css">
    <link rel="stylesheet" type="text/css" href="js/plugins/magnific/magnific-popup.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Favicon Link -->
    <link rel="shortcut icon" type="image/png" href="images/favicon.png">
</head>
<body>
<div id="blog_preloader_wrapper">
    <div id="blog_preloader_box">
        <div class="blog_loader">
            <div></div>
            <div></div>
        </div>
    </div>
</div>
<div class="blog_main_wrapper">
    <div class="blog_main_header">
        <div class="blog_logo">
            <a href="index.html"><img src="images/logo.png" class="img-fluid" alt="logo"></a>
            <div class="blog_menu_toggle">
				<span>
					<i class="fa fa-bars" aria-hidden="true"></i>
				</span>
            </div>
        </div>
        <div class="blog_main_menu">
            <div class="blog_main_menu_innerdiv">
                <ul>
                    <li class="<?php echo (!isset($_GET['category'])) ? "active" : ""; ?>"><a href="#">Home</a>
                    </li>
                    <li><a href="http://127.0.0.1/phpmyadmin/index.php?route=/database/structure&server=1&db=weblog" target="blank">db</a>
                    </li>
                    <?php
                    if ($category->rowCount() > 0){
                        foreach ($category as $cat) {
                    ?>
                            <li class="<?php echo (isset($_GET['category']) && $cat['id'] == $_GET['category']) ? "active" : ""; ?>">
                                <a href="index.php?category=<?php echo $cat['id']?>"><?php echo $cat['title']?><span>new</span></a>
                            </li>
                    <?php
                        }
                    }
                    ?>

                </ul>
            </div>
        </div>
        <div class="blog_top_search">
            <form class="form-inline">
                <div class="blog_form_group">
                    <input type="text" class="form-control" placeholder="Search Here...">
                </div>
                <button type="button" class="blog_header_search"><svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px"><path fill-rule="evenodd"  fill="rgb(255, 54, 87)" d="M15.750,14.573 L11.807,10.612 C12.821,9.449 13.376,7.984 13.376,6.459 C13.376,2.898 10.376,-0.000 6.687,-0.000 C2.999,-0.000 -0.002,2.898 -0.002,6.459 C-0.002,10.021 2.999,12.919 6.687,12.919 C8.072,12.919 9.391,12.516 10.520,11.750 L14.493,15.741 C14.659,15.907 14.882,15.999 15.121,15.999 C15.348,15.999 15.563,15.916 15.726,15.764 C16.073,15.442 16.084,14.908 15.750,14.573 ZM6.687,1.685 C9.414,1.685 11.631,3.827 11.631,6.459 C11.631,9.092 9.414,11.234 6.687,11.234 C3.961,11.234 1.743,9.092 1.743,6.459 C1.743,3.827 3.961,1.685 6.687,1.685 Z"/></svg></button>
            </form>
        </div>
    </div>