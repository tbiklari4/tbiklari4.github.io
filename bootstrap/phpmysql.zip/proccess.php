<?php
//$name = $_POST['name'];
//echo $name;











$name = $_FILES['file']['name'];
$tmp = $_FILES['file']['tmp_name'];
if (move_uploaded_file($tmp, "upload/$name")){
    echo "success";
    echo $_FILES['file']['size'] . " B";
}else {
    echo "error! :" . $_FILES['file']['error'];
}