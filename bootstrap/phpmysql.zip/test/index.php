<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="set.php" method="post">
    <label for="name">نام</label>
    <input type="text" id="name" name="name">
    <button type="submit">ارسال</button>
</form>
</body>
</html>